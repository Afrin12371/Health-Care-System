package com.cg.hms.entities;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Value;
@Entity
@Table(name = "appointment_details")
public class Appointment {
	@Id
	@GeneratedValue
	private Long appointmentId;
	@Column(name = "UserId")
	private int userid;
	@Column(name = "centerId")
	private int centerId;
	@Column(name = "TestId")
	private int testId;
	@Column(name = "Date")
	private Date date;
	@Column(name = "appointment_status")
	@Value("false")
	private boolean approved;
	
	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Appointment(Long appointmentId, int userid, int centerId, int testId, Date date, boolean approved) {
		super();
		this.appointmentId = appointmentId;
		this.userid = userid;
		this.centerId = centerId;
		this.testId = testId;
		this.date = date;
		this.approved = approved;
	}
	public Appointment(int userid, int centerId, int testId, Date date, boolean approved) {
		super();
		this.userid = userid;
		this.centerId = centerId;
		this.testId = testId;
		this.date = date;
		this.approved = approved;
	}
	
	public Appointment(int userid, int centerId, int testId, Date date) {
		super();
		this.userid = userid;
		this.centerId = centerId;
		this.testId = testId;
		this.date = date;
	}
	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", userid=" + userid + ", centerId=" + centerId
				+ ", testId=" + testId + ", date=" + date + ", approved=" + approved + "]";
	}
	public Long getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(Long appointmentId) {
		this.appointmentId = appointmentId;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getCenterId() {
		return centerId;
	}
	public void setCenterId(int centerId) {
		this.centerId = centerId;
	}
	public int getTestId() {
		return testId;
	}
	public void setTestId(int testId) {
		this.testId = testId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public boolean isApproved() {
		return approved;
	}
	public void setApproved(boolean approved) {
		this.approved = approved;
	}
	
	

}
