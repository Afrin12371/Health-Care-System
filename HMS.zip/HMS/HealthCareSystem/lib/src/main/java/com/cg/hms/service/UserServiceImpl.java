package com.cg.hms.service;


import java.util.Optional;

import org.slf4j.Logger;

//import org.apache.log4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hms.dao.IAppointmentDao;
import com.cg.hms.dao.IUserDao;
import com.cg.hms.entities.Appointment;
import com.cg.hms.entities.User;
import com.cg.hms.exception.AppiontmentIdDoesNotExistException;
import com.cg.hms.exception.UserAlreadyExistException;
import com.cg.hms.exception.UserDoesNotExistException;

@Service
@Transactional
public class UserServiceImpl implements IUserService{

	@Autowired
	private IUserDao dao;
	
	@Autowired
	private IAppointmentDao aDao;
	
	private Logger logger=LoggerFactory.getLogger(UserServiceImpl.class);

	@Override
	public User register(User user) {
		boolean exist = user.getUserId()!=null && dao.existsById(user.getUserId());
		if(exist) {
			throw new UserAlreadyExistException("The user already exist with id: " + user.getUserId());
			
		}
		user = dao.save(user);
		System.out.println(user);
		return user;
	}

	@Override
	public User findUser(int id) {
		Optional<User> userOpt = dao.findById(id);
		if(!userOpt.isPresent()) {
			logger.error("The user with id : "+ id+" does not exist");
			throw new UserDoesNotExistException("The user with id : "+ id+" does not exist");
		}
		User user = userOpt.get();
		return user;
	}

	@Override
	public Appointment createAppointment(Appointment apt) {
		apt = aDao.save(apt);
		return apt;
	}

	@Override
	public Appointment getAppointment(int id, int cid, int tid, long aid) {
		Optional<Appointment> aptOpt = aDao.findByUidCidTid(id,cid,tid,aid);
		if(!aptOpt.isPresent()) {
			logger.error("Appointment Id : "+ aid+" for User Id : "+
		id+" at Center with Id : "+ cid+" not present");
			throw new AppiontmentIdDoesNotExistException("Appointment Id : "+ aid+" for User Id : "+
		id+" at Center with Id : "+ cid+" not present");
		}
		Appointment apt = aptOpt.get();
		return apt;
	}

}
