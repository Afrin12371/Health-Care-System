package com.cg.hms.util;

import org.springframework.stereotype.Component;
 import com.cg.hms.dto.UserDetails;
import com.cg.hms.entities.User;
@Component

public class UserUtil {
	public UserDetails toDetails(User user) {
		
         return new UserDetails(user.getUserId(),user.getUserName(),user.getContactNo(),user.getGender(),user.getAge());
    }
	
   }
