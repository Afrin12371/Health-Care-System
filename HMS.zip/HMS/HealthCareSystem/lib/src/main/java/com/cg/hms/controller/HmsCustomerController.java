package com.cg.hms.controller;

import java.sql.Date;
import java.util.List;
import java.util.Set;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hms.dto.CenterDetails;
import com.cg.hms.dto.CreateCenterRequest;
import com.cg.hms.dto.CreateUserRequest;
import com.cg.hms.dto.TestDetails;
import com.cg.hms.dto.UserDetails;
import com.cg.hms.dto.UserLoginDetailsDto;
import com.cg.hms.entities.Appointment;
import com.cg.hms.entities.DiagnosticCenter;
import com.cg.hms.entities.Test;
import com.cg.hms.entities.User;
import com.cg.hms.entities.UserLoginDetails;
import com.cg.hms.exception.LoginRequiredException;
import com.cg.hms.exception.MinimumRequiredTests;
import com.cg.hms.exception.NotAccessableException;
import com.cg.hms.exception.TestNameAlreadyExistException;
import com.cg.hms.service.IDiagnosticService;
import com.cg.hms.service.IHmsRegister;
import com.cg.hms.service.IUserService;
import com.cg.hms.util.DiagnosticUtil;
import com.cg.hms.util.UserUtil;

@RestController
@RequestMapping("/hms_cust")
@Validated

public class HmsCustomerController {

	@Autowired
	private IUserService userService;

	@Autowired
	private IDiagnosticService dService;
	@Autowired
	private UserUtil userUtil;
	@Autowired
	private DiagnosticUtil dUtil;

	@Autowired
	private IHmsRegister hmsRegister;

	private Logger logger = LoggerFactory.getLogger(HmsCustomerController.class);

	//Only for User
	@ResponseStatus(HttpStatus.CREATED)
	@PostMapping("/addUser")
	public UserDetails add(@RequestBody @Valid CreateUserRequest requestData, HttpServletRequest request) {
		System.out.println("reqestData:" + requestData);
		HttpSession session = request.getSession();
		if(session.getAttribute("username")==null) {
			throw new LoginRequiredException("Please login to access application");
		}
		if(!session.getAttribute("role").equals("Customer")) {
			throw new NotAccessableException("Not Accessble by : " +session.getAttribute("role"));
		}
		if(session.getAttribute("userid")!= null) {
			throw new NotAccessableException("User Details Already updated");
		}
		User user = new User(requestData.getUserName(), requestData.getContactNo(), requestData.getGender(),
				requestData.getAge());
		System.out.println(user);
		user = userService.register(user);
		Object uName = session.getAttribute("username");
		String name = (String) uName;
		UserLoginDetails uld = hmsRegister.findByUserName(name);
		System.out.println(uld);
		uld.setuserid(user.getUserId());
		uld = hmsRegister.register1(uld);
		logger.info("User Registered");
		UserDetails details = userUtil.toDetails(user);		
		return details;
	}

	

	//For both user and Admin
	@GetMapping("/displayCenters")
	public List<CenterDetails> display(HttpServletRequest request) {
		System.out.println("Displaying all Diagnostic Centers");
		HttpSession session = request.getSession();
		if(session.getAttribute("username")==null) {
			throw new LoginRequiredException("Please login to access application");
		}
		List<DiagnosticCenter> center = dService.findAll();
		List<Test> test = dService.findAllTest();
		logger.info("Displayed all Diagnostic Centers");
		List<CenterDetails> details = dUtil.toDisplayDetails(center, test);
		return details;

	}
	
	//For User
	@GetMapping("/createAppointment/{centerid}/{testid}/{date}")
	public Appointment createAppointment(@PathVariable("centerid") int cid,
			@PathVariable("testid") int tid, @PathVariable("date") Date date, HttpServletRequest request) {
		System.out.println("Booking appointment...");
		HttpSession session = request.getSession();
		if(session.getAttribute("username")==null) {
			throw new LoginRequiredException("Please login to access application");
		}
		String role = (String) session.getAttribute("role");
		if(!role.equalsIgnoreCase("Customer")) {
			throw new NotAccessableException("Not Accessble by : " +session.getAttribute("role"));
		}
		if(session.getAttribute("userid")== null) { 
			throw new LoginRequiredException("Please update user information in addUser()");
		}
		Object uid = session.getAttribute("userid");
		int id = (int) uid;
		User user = userService.findUser(id);
		DiagnosticCenter center = dService.findById(cid);
		Test test = dService.findByTIdCId(cid, tid);
		Appointment apt = new Appointment(id, cid, tid, date);		
		logger.info("Appointment created for  User Id : " + id + " successfully");
		apt = userService.createAppointment(apt);
		return apt;

	}

	

	@ResponseStatus(HttpStatus.ACCEPTED)
	@PostMapping("/register")
	public String register(@RequestBody UserLoginDetailsDto uld, HttpServletRequest request) {
		UserLoginDetails uDetails = new UserLoginDetails(uld.getUsername(), uld.getPassword(), uld.getUserrole());
		uDetails = hmsRegister.register(uDetails);
		return "Registeration successful with userName :" + uDetails.getUsername() + " Role -> "
				+ uDetails.getUserRole();
	}

	@ResponseStatus(HttpStatus.ACCEPTED)
	@PostMapping("/login")
	public String login(@RequestBody UserLoginDetailsDto uld, HttpServletRequest request) {
		HttpSession session = request.getSession();
		UserLoginDetails uDetails = hmsRegister.findByName(uld);
		session.setAttribute("username", uDetails.getUsername());
		session.setAttribute("role", uDetails.getUserRole());
		session.setAttribute("userid", uDetails.getuserid());
		return "Login successful.... Welcome to HMS " + uDetails.getUsername() + " Role ->" + uDetails.getUserRole();
	}

	@ResponseStatus(HttpStatus.ACCEPTED)
	@PostMapping("/logout")
	public String logout(@RequestBody UserLoginDetailsDto uld, HttpServletRequest request) {
		HttpSession session = request.getSession();
		if (uld.getUsername().equals(session.getAttribute("username"))) {
			session.invalidate();
			return "You have successfully logged out " + uld.getUsername();
		}
		return "Not Logged off";
	}

}

