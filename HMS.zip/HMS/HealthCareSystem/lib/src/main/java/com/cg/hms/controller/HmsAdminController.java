package com.cg.hms.controller;

import java.sql.Date;
import java.util.List;
import java.util.Set;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hms.dto.CenterDetails;
import com.cg.hms.dto.CreateCenterRequest;
import com.cg.hms.dto.CreateUserRequest;
import com.cg.hms.dto.TestDetails;
import com.cg.hms.dto.UserDetails;
import com.cg.hms.dto.UserLoginDetailsDto;
import com.cg.hms.entities.Appointment;
import com.cg.hms.entities.DiagnosticCenter;
import com.cg.hms.entities.Test;
import com.cg.hms.entities.User;
import com.cg.hms.entities.UserLoginDetails;
import com.cg.hms.exception.LoginRequiredException;
import com.cg.hms.exception.MinimumRequiredTests;
import com.cg.hms.exception.NotAccessableException;
import com.cg.hms.exception.TestNameAlreadyExistException;
import com.cg.hms.service.IDiagnosticService;
import com.cg.hms.service.IHmsRegister;
import com.cg.hms.service.IUserService;
import com.cg.hms.util.DiagnosticUtil;
import com.cg.hms.util.UserUtil;

@RestController
@RequestMapping("/hms")
@Validated

public class HmsAdminController {

	@Autowired
	private IUserService userService;

	@Autowired
	private IDiagnosticService dService;
	@Autowired
	private UserUtil userUtil;
	@Autowired
	private DiagnosticUtil dUtil;

	@Autowired
	private IHmsRegister hmsRegister;

	private Logger logger = LoggerFactory.getLogger(HmsAdminController.class);

	

	// Only Admin
	@ResponseStatus(HttpStatus.CREATED)
	@PostMapping("/addCenter")
	public CenterDetails add(@RequestBody @Valid CreateCenterRequest requestData, HttpServletRequest request) {
		System.out.println(requestData);
		HttpSession session = request.getSession();
		if (session.getAttribute("username") == null) {
			throw new LoginRequiredException("Please login to access application");
		}
		if (!session.getAttribute("role").equals("admin")) {
			throw new NotAccessableException("Not Accessble by : " + session.getAttribute("role"));
		}
		DiagnosticCenter center = new DiagnosticCenter(requestData.getCenterName());
		System.out.println(center);
		Set<Test> testSet = requestData.getListOfTests();
		if (testSet != null) {
			for (Test test : testSet) {
				center.addTest(test);

			}
		}
//		if (testSet.size() < 3) {
//			logger.error("Did not received minimum number of tests. No of Tests entered : \" + testSet.size()");
//			throw new MinimumRequiredTests(
//					"Did not received minimum number of tests. No of Tests entered : " + testSet.size());
//		}
		System.out.println(center);
		center = dService.register(center);
		logger.info("Diagnostic Center added Successfully");
		CenterDetails details = dUtil.toDetails(center);
		return details;
	}

	// Only Admin
	@GetMapping("/removeCenterbyid/{id}")
	public CenterDetails remove(@PathVariable("id") Integer id, HttpServletRequest request) {
		HttpSession session = request.getSession();
		if (session.getAttribute("username") == null) {
			throw new LoginRequiredException("Please login to access application");
		}
		if (!session.getAttribute("role").equals("admin")) {
			throw new NotAccessableException("Not Accessble by : " + session.getAttribute("role"));
		}
		System.out.println("Controller Remove center by id: " + id);
		DiagnosticCenter center = dService.findById(id);
		Set<TestDetails> tDetails = dUtil.toDetails(center.getListOfTests());
		Set<Test> test = dService.remove(center.getCenterId());
		CenterDetails details = dUtil.toDetails(center, tDetails);
		center = dService.removeCenter(center);
		logger.info("Removed Diagnstic center id: " + id + " successfully");
		System.out.println(center);
		return details;
	}

	// Only Admin
	@GetMapping("/addTest/{testName}/{dcenterId}")
	public CenterDetails addTest(@PathVariable("testName") String testName, @PathVariable("dcenterId") Integer id,
			HttpServletRequest request) {
		System.out.println("Controller Check centerId :" + id);
		HttpSession session = request.getSession();
		if (session.getAttribute("username") == null) {
			throw new LoginRequiredException("Please login to access application");
		}
		if (!session.getAttribute("role").equals("admin")) {
			throw new NotAccessableException("Not Accessble by : " + session.getAttribute("role"));
		}
		DiagnosticCenter center = dService.findById(id);
		List<Test> getAllTests = dService.findByCId(id);
		for (Test test1 : getAllTests) {
			if (test1.getTestName().equalsIgnoreCase(testName)) {
				logger.error("Entered test name Already exist :" + testName);
				throw new TestNameAlreadyExistException("Entered test name Already exist :" + testName);
			}
		}
		Test test = new Test(testName);
		center.addSingleTest(test, center);
		test = dService.addSingleTest(test);
		logger.info("Test addded : " + testName);
		CenterDetails details = dUtil.toDetails(center, test);
		return details;
	}

	// Only Admin
	@GetMapping("/removeTest/{centerId}/{testId}")
	public CenterDetails removeTest(@PathVariable("centerId") Integer id, @PathVariable("testId") Integer tId,
			HttpServletRequest request) {
		System.out.println("Controller remove test by Id: " + tId + " at center id: " + id);
		HttpSession session = request.getSession();
		if (session.getAttribute("username") == null) {
			throw new LoginRequiredException("Please login to access application");
		}
		if (!session.getAttribute("role").equals("admin")) {
			throw new NotAccessableException("Not Accessble by : " + session.getAttribute("role"));
		}
		DiagnosticCenter center = dService.findById(id);
		Test test = dService.findByTIdCId(id, tId);
		TestDetails tDetails = new TestDetails(test);
		System.out.println(tDetails);
		dService.removeTest(test);
		System.out.println(center);
		logger.info("Removed test Id : " + tId + " at center id: " + id + " successfully");
		CenterDetails details = dUtil.toDetails(center, tDetails);
		return details;
	}

	//for both user and Admin
	@GetMapping("/displayCenters")
	public List<CenterDetails> display(HttpServletRequest request) {
		System.out.println("Displaying all Diagnostic Centers");
		HttpSession session = request.getSession();
		if(session.getAttribute("username")==null) {
			throw new LoginRequiredException("Please login to access application");
		}
		List<DiagnosticCenter> center = dService.findAll();
		List<Test> test = dService.findAllTest();
		logger.info("Displayed all Diagnostic Centers");
		List<CenterDetails> details = dUtil.toDisplayDetails(center, test);
		return details;

	}
	
	

	//For only Admin
	@GetMapping("/approveAppointment/{userid}/{centerid}/{testid}/{appid}/{approval}")
	public Appointment approveAppointment(@PathVariable("userid") int id, @PathVariable("centerid") int cid,
			@PathVariable("testid") int tid, @PathVariable("approval") boolean approved,
			@PathVariable("appid") long aid, HttpServletRequest request) {
		System.out.println("Approving appointment...");
		HttpSession session = request.getSession();
		if (session.getAttribute("username") == null) {
			throw new LoginRequiredException("Please login to access application");
		}
		if (!session.getAttribute("role").equals("admin")) {
			throw new NotAccessableException("Not Accessble by : " + session.getAttribute("role"));
		}
		User user = userService.findUser(id);
		DiagnosticCenter center = dService.findById(cid);
		Test test = dService.findByTIdCId(cid, tid);
		Appointment apt = userService.getAppointment(id, cid, tid, aid);
		apt.setApproved(approved);
		logger.info("Appointment approved for User Id : " + id + "for test Id : " + tid + " in center with Id : " + cid
				+ " successfully");
		apt = userService.createAppointment(apt);
		return apt;

	}

	@ResponseStatus(HttpStatus.ACCEPTED)
	@PostMapping("/register")
	public String register(@RequestBody UserLoginDetailsDto uld, HttpServletRequest request) {
		UserLoginDetails uDetails = new UserLoginDetails(uld.getUsername(), uld.getPassword(), uld.getUserrole());
		uDetails = hmsRegister.register(uDetails);
		return "Registeration successful with userName :" + uDetails.getUsername() + " Role -> "
				+ uDetails.getUserRole();
	}

	@ResponseStatus(HttpStatus.ACCEPTED)
	@PostMapping("/login")
	public String login(@RequestBody UserLoginDetailsDto uld, HttpServletRequest request) {
		HttpSession session = request.getSession();
		UserLoginDetails uDetails = hmsRegister.findByName(uld);
		session.setAttribute("username", uDetails.getUsername());
		session.setAttribute("role", uDetails.getUserRole());
		session.setAttribute("userid", uDetails.getuserid());
		return "Login successful.... Welcome to HMS " + uDetails.getUsername() + " Role ->" + uDetails.getUserRole();
	}

	@ResponseStatus(HttpStatus.ACCEPTED)
	@PostMapping("/logout")
	public String logout(@RequestBody UserLoginDetailsDto uld, HttpServletRequest request) {
		HttpSession session = request.getSession();
		if (uld.getUsername().equals(session.getAttribute("username"))) {
			session.invalidate();
			return "You have successfully logged out " + uld.getUsername();
		}
		return "Not Logged off";
	}

}
