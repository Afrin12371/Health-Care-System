package com.cg.hms.service;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
//import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.cg.hms.dao.IUserDao;
import com.cg.hms.entities.DiagnosticCenter;
import com.cg.hms.entities.User;
import com.cg.hms.service.IUserService;
import com.cg.hms.service.UserServiceImpl;

import springfox.documentation.swagger2.annotations.EnableSwagger2;
@ExtendWith({SpringExtension.class})
@DataJpaTest
@Import(UserServiceImpl.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)

public class UserServiceImplTest {
	@Autowired
	private IUserService uService;
	@Autowired
	private EntityManager em;
	
	@Test
	public void testFindUser() {
		User ufind = new User("aaaa", 1234567809L, "Male", 26); 
		em.persist(ufind);
		Integer id = ufind.getUserId();
		User uf = uService.findUser(id);
		Assertions.assertEquals(uf.getAge(),ufind.getAge());
	}
	
//	@Test
//	public void testRegister() {
//		User user=new User ("xxxx", 554466325L, "Female", 30);
//		em.persist(user);
//		User us=uService.register(user);
//		Assertions.assertEquals(user.getGender(), "Female");
//		
//	}

}
