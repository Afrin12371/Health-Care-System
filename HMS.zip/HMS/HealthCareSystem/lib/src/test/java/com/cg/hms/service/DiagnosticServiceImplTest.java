package com.cg.hms.service;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
//import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import com.cg.hms.entities.DiagnosticCenter;
import com.cg.hms.service.DiagnosticServiceImpl;
import com.cg.hms.service.IDiagnosticService;

import springfox.documentation.swagger2.annotations.EnableSwagger2;
@ExtendWith({SpringExtension.class})
@DataJpaTest
@Import(DiagnosticServiceImpl.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)

public class DiagnosticServiceImplTest {
	@Autowired
	private IDiagnosticService service;
	@Autowired
	private EntityManager em;
	private String listOfTests;
	@org.junit.jupiter.api.Test
	
	public void testRegister() {
			DiagnosticCenter center = new DiagnosticCenter("apollo");
			em.persist(center);
			DiagnosticCenter dreg= service.register(center);
			Assertions.assertEquals(dreg.getCenterName(),"apollo");
			
		}

	@Test
	public void testRemoveCenter() {
		DiagnosticCenter center2 = new DiagnosticCenter("apollo");
		em.persist(center2);
		DiagnosticCenter dremove= service.removeCenter(center2);
		Assertions.assertEquals(dremove.getCenterName(),"apollo");
		}
	
	@Test
	public void testFindAll() {
		List<DiagnosticCenter> center = service.findAll();
		Assertions.assertTrue(center.size()>0); 
	}
	
//	@Test
//	public void testFindByCId() {
//		DiagnosticCenter center = new DiagnosticCenter("apollo");
//		em.persist(center);
//		List<Test> byId = service.findByCId(4);
//		Assertions.assertEquals(center.get(0), 4);
//		
//	}
	
	@Test
	public void testfindById() {
		DiagnosticCenter cent = new DiagnosticCenter("apollo");
		em.persist(cent);
		Integer id = cent.getCenterId();
		DiagnosticCenter dc = service.findById(id);
		System.out.println(dc);
		Assertions.assertEquals(dc.getCenterName(),"apollo");
	}
	
//	@Test
//	public void testRemoveTest() {
//		DiagnosticCenter test = new DiagnosticCenter("apollo");
//		em.persist(test);
//		DiagnosticCenter testRemove = service.removeTest(test);
//		
//	}
}
	

	