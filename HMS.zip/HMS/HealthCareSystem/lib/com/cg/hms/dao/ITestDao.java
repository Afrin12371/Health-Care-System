package com.cg.hms.dao;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.hms.entities.Test;
@Repository
public interface ITestDao extends JpaRepository<Test, Integer> {
	
@Query("from Test where dcenter_id=:centerId")
	Set<Test> findByCenterId(@Param("centerId")  Integer centerId);

@Query("from Test where dcenter_id=:id and test_id=:tId")
Optional<Test> findbyTIdCid(@Param("id") Integer id,@Param("tId") Integer tId);

@Query("from Test where dcenter_id=:id")
List<Test> findbyCid(@Param("id") Integer id);

}
