package com.cg.hms.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.hms.entities.Appointment;

@Repository
public interface IAppointmentDao extends JpaRepository<Appointment, Long> {
	
	@Query("from Appointment where appointment_id=:aid and user_id=:id and center_id=:cid and test_id=:tid ")
	Optional<Appointment> findByUidCidTid(@Param("id") int id,@Param("cid") int cid,
			@Param("tid") int tid, @Param("aid") long aid);

}
