package com.cg.hms.service;

import com.cg.hms.entities.Appointment;
import com.cg.hms.entities.User;

public interface IUserService {

	User register(User user);

	User findUser(int id);

	Appointment createAppointment(Appointment apt);

	Appointment getAppointment(int id, int cid, int tid, long aid);

}
