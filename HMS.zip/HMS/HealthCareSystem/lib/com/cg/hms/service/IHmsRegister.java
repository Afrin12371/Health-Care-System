package com.cg.hms.service;

import com.cg.hms.dto.UserLoginDetailsDto;
import com.cg.hms.entities.UserLoginDetails;

public interface IHmsRegister {

	UserLoginDetails register(UserLoginDetails uDetails);

	UserLoginDetails findByName(UserLoginDetailsDto uld);

	UserLoginDetails findByUserName(String name);

	UserLoginDetails register1(UserLoginDetails uld);

}
