package com.cg.hms.service;


import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hms.controller.HmsAdminController;
import com.cg.hms.dao.IDiagnosticDao;
import com.cg.hms.dao.ITestDao;
import com.cg.hms.entities.DiagnosticCenter;
import com.cg.hms.entities.Test;
import com.cg.hms.exception.CenterNotFoundException;
import com.cg.hms.exception.TestDoesNotExistException;
@Service
@Transactional
public class DiagnosticServiceImpl implements IDiagnosticService {

	@Autowired
	private IDiagnosticDao dao;
	
	@Autowired
	private ITestDao tDao;
	
	private Logger logger=Logger.getLogger(DiagnosticServiceImpl.class);

	
	@Override
	public DiagnosticCenter register(DiagnosticCenter center) {
		center = dao.save(center);
		return center;
	}
	@Override
	public DiagnosticCenter findById(Integer id) {
		Optional<DiagnosticCenter> centerOpt = dao.findById(id);
		if(!centerOpt.isPresent()) {
			logger.error("Center not found for Id : "+ id);
			throw new CenterNotFoundException("Center not found for Id : "+ id);
		}
		DiagnosticCenter center = centerOpt.get();
		
		return center;
	}
	@Override
	public Set<Test> remove(Integer centerId) {
		Set<Test> tests = tDao.findByCenterId(centerId);
		for(Test test : tests) {
			tDao.deleteById(test.getTestId());
		}
		return tests;
	}		
	@Override
	public DiagnosticCenter removeCenter(DiagnosticCenter center) {
		dao.deleteById(center.getCenterId());

		return center;
	}
	@Override
	public Test addSingleTest(Test test) {
		test = tDao.save(test);
		return test;
	}
	@Override
	public Test findByTIdCId(Integer id, Integer tId) {
		Optional<Test> opt = tDao.findbyTIdCid(id,tId);
		if(!opt.isPresent()) {
			logger.error("Entered Test id : " + tId +
					" not available for Diagnostic center with id : "+ id);
			throw new TestDoesNotExistException("Entered Test id : " + tId +
					" not available for Diagnostic center with id : "+ id);
		}
		Test test = opt.get();
		
		return test;
	}
	@Override
	public void removeTest(Test test) {
		tDao.deleteById(test.getTestId());
		
	}
	@Override
	public List<Test> findByCId(Integer id) {
		List<Test> testList = tDao.findbyCid(id);
		return testList;
	}
	@Override
	public List<DiagnosticCenter> findAll() {
		List<DiagnosticCenter> center = dao.findAll();
		return center;
	}
	@Override
	public List<Test> findAllTest() {
		List<Test> test =  tDao.findAll();
		return test;
	}
	
	

}
