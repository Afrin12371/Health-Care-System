package com.cg.hms.service;

import java.util.List;
import java.util.Set;

import com.cg.hms.entities.DiagnosticCenter;
import com.cg.hms.entities.Test;

public interface IDiagnosticService {

	DiagnosticCenter register(DiagnosticCenter center);

	DiagnosticCenter findById(Integer id);

	Set<Test> remove(Integer centerId);

	DiagnosticCenter removeCenter(DiagnosticCenter center);

	Test addSingleTest(Test test);

	Test findByTIdCId(Integer id, Integer tId);

	void removeTest(Test test);

	List<Test> findByCId(Integer id);

	List<DiagnosticCenter> findAll();

	List<Test> findAllTest();

}
