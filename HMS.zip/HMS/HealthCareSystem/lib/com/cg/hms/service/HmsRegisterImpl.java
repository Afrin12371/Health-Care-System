package com.cg.hms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hms.dao.IHmsRegistrationDao;
import com.cg.hms.dto.UserLoginDetailsDto;
import com.cg.hms.entities.UserLoginDetails;
import com.cg.hms.exception.PasswordAuthenticationException;
import com.cg.hms.exception.UserNameAlreadyExist;
import com.cg.hms.exception.UserRegistrationException;

@Service
@Transactional
public class HmsRegisterImpl implements IHmsRegister {

	@Autowired
	private IHmsRegistrationDao dao;

	@Override
	public UserLoginDetails register(UserLoginDetails uDetails) {
		List<UserLoginDetails> uList = dao.findAll();
		for (UserLoginDetails user : uList) {
			if (user.getUsername().equals(uDetails.getUsername())) {
				throw new UserNameAlreadyExist("User with Username : " + uDetails.getUsername() + " already exists");

			}

		}
		UserLoginDetails details = dao.save(uDetails);
		return details;
	}

	@Override
	public UserLoginDetails findByName(UserLoginDetailsDto uld) {
		Optional<UserLoginDetails> opt = dao.findById(uld.getUsername());
		if (!opt.isPresent()) {
			throw new UserRegistrationException("User with Username : " + uld.getUsername() + " not Registered");
		}
		UserLoginDetails userDetails = opt.get();
		if (!uld.getPassword().equals(userDetails.getPassword())) {
			throw new PasswordAuthenticationException("Invalid Credentials");
		}
		return userDetails;
	}

	@Override
	public UserLoginDetails findByUserName(String name) {
		Optional<UserLoginDetails> opt = dao.findById(name);
		return opt.get();
	}

	@Override
	public UserLoginDetails register1(UserLoginDetails uld) {
		UserLoginDetails details = dao.save(uld);
		return details;
	}

}
