package com.cg.hms.dto;

public class CreateUserRequest {
	private String userName;
	private long contactNo;
	private String gender;
	private int age;
	public CreateUserRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CreateUserRequest(String userName, long contactNo, String gender, int age) {
		super();
		this.userName = userName;
		this.contactNo = contactNo;
		this.gender = gender;
		this.age = age;
	}
	@Override
	public String toString() {
		return "CreateUserRequest [userName=" + userName + ", contactNo=" + contactNo + ", gender=" + gender + ", age="
				+ age + "]";
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	

}
