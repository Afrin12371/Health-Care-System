package com.cg.hms.dto;

import com.cg.hms.entities.Test;

public class TestDetails {

	private Integer testId;
	private String testName;
	public TestDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TestDetails(Integer testId, String testName) {
		super();
		this.testId = testId;
		this.testName = testName;
	}
	public TestDetails(Test test1) {
		this.testId = test1.getTestId();
		this.testName = test1.getTestName();
	}
	@Override
	public String toString() {
		return "TestDetails [testId=" + testId + ", testName=" + testName + "]";
	}
	public Integer getTestId() {
		return testId;
	}
	public void setTestId(Integer testId) {
		this.testId = testId;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	
	

}
