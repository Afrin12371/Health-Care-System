package com.cg.hms.dto;

import java.util.Set;

public class CenterDetails {
	private Integer centerId;
	private String centerName;
	private Set<TestDetails> listOfTests;
	public CenterDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CenterDetails(Integer centerId2, String centerName2, Set<TestDetails> details) {
		this.centerId = centerId2;
		this.centerName = centerName2;
		this.listOfTests = details;
	}
	@Override
	public String toString() {
		return "CenterDetails [centerId=" + centerId + ", centerName=" + centerName + ", listOfTests=" + listOfTests
				+ "]";
	}
	public Integer getCenterId() {
		return centerId;
	}
	public void setCenterId(Integer centerId) {
		this.centerId = centerId;
	}
	public String getCenterName() {
		return centerName;
	}
	public void setCenterName(String centerName) {
		this.centerName = centerName;
	}
	public Set<TestDetails> getListOfTests() {
		return listOfTests;
	}
	public void setListOfTests(Set<TestDetails> listOfTests) {
		this.listOfTests = listOfTests;
	}

	

}
