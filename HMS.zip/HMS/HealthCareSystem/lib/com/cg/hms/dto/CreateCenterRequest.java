package com.cg.hms.dto;

import java.util.Set;

import com.cg.hms.entities.Test;

public class CreateCenterRequest {
	
	private String centerName;
	private Set<Test> listOfTests;
	public CreateCenterRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CreateCenterRequest(String centerName, Set<Test> listOfTests) {
		super();
		this.centerName = centerName;
		this.listOfTests = listOfTests;
	}
	

	@Override
	public String toString() {
		return "CreateCenterRequest [centerName=" + centerName + ", listOfTests=" + listOfTests + "]";
	}
	public String getCenterName() {
		return centerName;
	}
	public void setCenterName(String centerName) {
		this.centerName = centerName;
	}
	public Set<Test> getListOfTests() {
		return listOfTests;
	}
	public void setListOfTests(Set<Test> listOfTests) {
		this.listOfTests = listOfTests;
	}
	

}
