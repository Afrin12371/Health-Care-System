package com.cg.hms.dto;

public class CreateTestRequest {
	private String testName;

	public CreateTestRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CreateTestRequest(String testName) {
		super();
		this.testName = testName;
	}

	@Override
	public String toString() {
		return "CreateTestRequest [testName=" + testName + "]";
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}
	

}
