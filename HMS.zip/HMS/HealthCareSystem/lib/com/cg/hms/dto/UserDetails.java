package com.cg.hms.dto;

public class UserDetails {
	private Integer userId;
	private String userName;
	private long contactNo;
	private String gender;
	private int age;
	public UserDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserDetails(Integer userId, String userName, long contactNo, String gender, int age) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.contactNo = contactNo;
		this.gender = gender;
		this.age = age;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "UserDetails [userId=" + userId + ", userName=" + userName + ", contactNo=" + contactNo + ", gender="
				+ gender + ", age=" + age + "]";
	}
	

}
