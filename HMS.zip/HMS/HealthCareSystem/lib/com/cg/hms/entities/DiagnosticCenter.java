package com.cg.hms.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;


@Entity
@Table(name = "center_details")
public class DiagnosticCenter {
	@Id
	@GeneratedValue
	private Integer centerId;
	@Column(name = "centerName")
	private String centerName;
	@OneToMany(mappedBy = "dCenter")	
	@Cascade(CascadeType.ALL)
	private Set<Test> listOfTests = new HashSet<Test>();// to prevent nullPointerException
	
	
	public DiagnosticCenter() {
		super();
	}
	public DiagnosticCenter(Integer centerId, String centerName, Set<Test> listOfTests) {
		super();
		this.centerId = centerId;
		this.centerName = centerName;
		this.listOfTests = listOfTests;
	}
	
	public DiagnosticCenter(String centerName, Set<Test> listOfTests) {
		super();
		this.centerName = centerName;
		this.listOfTests = listOfTests;
	}
	
	public DiagnosticCenter(String centerName) {
		super();
		this.centerName = centerName;
	}
	
	public DiagnosticCenter(Integer centerId, String centerName) {
		super();
		this.centerId = centerId;
		this.centerName = centerName;
	}
	@Override
	public String toString() {
		return "DiagnosticCenter [centerId=" + centerId + ", centerName=" + centerName + ", listOfTests=" + listOfTests
				+ "]";
	}
	public Integer getCenterId() {
		return centerId;
	}
	public void setCenterId(Integer centerId) {
		this.centerId = centerId;
	}
	public String getCenterName() {
		return centerName;
	}
	public void setCenterName(String centerName) {
		this.centerName = centerName;
	}
	public Set<Test> getListOfTests() {
		return listOfTests;
	}
	public void setListOfTests(Set<Test> listOfTests) {
		this.listOfTests = listOfTests;
	}
	public void addTest(Test test) {
		test.setdCenter(this);
		listOfTests.add(test);
		
	}
	public void addSingleTest(Test test, DiagnosticCenter center) {
		test.setdCenter(center);
		
	}
	
	
	

}