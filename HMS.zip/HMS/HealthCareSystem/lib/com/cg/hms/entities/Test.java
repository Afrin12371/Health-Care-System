package com.cg.hms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "test_details")
public class Test {
	@Id
	@GeneratedValue
	private Integer testId;
	@Column(name = "testName")
	private String testName;
	@ManyToOne
	@JoinColumn(name = "dcenter_id")
	private DiagnosticCenter dCenter;

	public DiagnosticCenter getdCenter() {
		return dCenter;
	}

	public void setdCenter(DiagnosticCenter dCenter) {
		this.dCenter = dCenter;
	}

	public Test() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Test(Integer testId, String testName) {
		super();
		this.testId = testId;
		this.testName = testName;
	}

	public Test(String testName) {
		super();
		this.testName = testName;
	}

	

	public Test(Test test) {
		this.testId = test.getTestId();
		this.testName = test.getTestName();
				
	}

	@Override
	public String toString() {
		return "Test [testId=" + testId + ", testName=" + testName + "]";
	}

	public Integer getTestId() {
		return testId;
	}

	public void setTestId(Integer testId) {
		this.testId = testId;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

}
