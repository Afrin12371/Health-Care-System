package com.cg.hms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "user_all_details")
public class User {
	@Id
	@GeneratedValue
	private Integer userId;
	@Column(name="userName")
	private String userName;
	@Column(name="contactNo")
	private long contactNo;
	@Column(name = "gender")
	private String gender;
	@Column(name = "age")
	private int age;
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(Integer userId, String userName, long contactNo, String gender, int age) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.contactNo = contactNo;
		this.gender = gender;
		this.age = age;
	}
	public User(String userName, long contactNo, String gender, int age) {
		super();
		this.userName = userName;
		this.contactNo = contactNo;
		this.gender = gender;
		this.age = age;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", contactNo=" + contactNo + ", gender=" + gender
				+ ", age=" + age + "]";
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	
	

}

