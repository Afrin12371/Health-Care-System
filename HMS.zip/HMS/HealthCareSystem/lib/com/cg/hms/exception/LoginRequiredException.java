package com.cg.hms.exception;

public class LoginRequiredException extends RuntimeException {

	public LoginRequiredException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
