package com.cg.hms.exception;

public class MinimumRequiredTests extends RuntimeException {

	public MinimumRequiredTests(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
