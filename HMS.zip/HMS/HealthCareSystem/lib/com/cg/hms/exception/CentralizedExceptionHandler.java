package com.cg.hms.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cg.hms.entities.Appointment;

@RestControllerAdvice
public class CentralizedExceptionHandler {
	//All custom exceptions are handled.
	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(Exception.class)
	public String handleAllExcptions(Exception e) {
		return e.getMessage();
	}
	
	
//	@ResponseStatus(HttpStatus.NOT_FOUND)
//	@ExceptionHandler(MinimumRequiredTests.class)
//	public String handleTest(MinimumRequiredTests e) {
//		return e.getMessage();
//		
//	}
//	
//	@ResponseStatus(HttpStatus.NOT_FOUND)
//	@ExceptionHandler(CenterNotFoundException.class)
//	public String handleCenterNotFound(CenterNotFoundException e) {
//		return e.getMessage();
//	}
//	
//	@ResponseStatus(HttpStatus.NOT_FOUND)
//	@ExceptionHandler(UserAlreadyExistException.class)
//	public String handleUserNotFound(UserAlreadyExistException e) {
//		return e.getMessage();	
//	}
//	
//	@ResponseStatus(HttpStatus.NOT_FOUND)
//	@ExceptionHandler(TestNameAlreadyExistException.class)
//	public String handleTestNameExist(TestNameAlreadyExistException e) {
//		return e.getMessage();
//				
//	}
//	
//	@ResponseStatus(HttpStatus.NOT_FOUND)
//	@ExceptionHandler(TestDoesNotExistException.class)
//	public String handleTestDoesNotExist(TestDoesNotExistException e) {
//		return e.getMessage();
//				
//	}
//	
//	@ResponseStatus(HttpStatus.NOT_FOUND)
//	@ExceptionHandler(UserDoesNotExistException.class)
//	public String handleUserDoesNotExist(UserDoesNotExistException e) {
//		return e.getMessage();
//				
//	}
//	@ResponseStatus(HttpStatus.NOT_FOUND)
//	@ExceptionHandler(AppiontmentIdDoesNotExistException.class)
//	public String handleAppiontmentIdDoesNotExist(AppiontmentIdDoesNotExistException e) {
//		return e.getMessage();
//				
//	}


}
