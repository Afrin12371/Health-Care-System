package com.cg.hms.exception;

public class NotAccessableException extends RuntimeException {

	public NotAccessableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
