package com.cg.hms.exception;

public class UserRegistrationException extends RuntimeException {

	public UserRegistrationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
