package com.cg.hms.exception;

public class AppiontmentIdDoesNotExistException extends RuntimeException {

	public AppiontmentIdDoesNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
