package com.cg.hms.exception;

public class CenterNotFoundException extends RuntimeException {

	public CenterNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
