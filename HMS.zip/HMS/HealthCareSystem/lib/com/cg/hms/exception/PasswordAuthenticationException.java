package com.cg.hms.exception;

public class PasswordAuthenticationException extends RuntimeException {

	public PasswordAuthenticationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
