package com.cg.hms.exception;

public class TestNameAlreadyExistException extends RuntimeException {

	public TestNameAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
