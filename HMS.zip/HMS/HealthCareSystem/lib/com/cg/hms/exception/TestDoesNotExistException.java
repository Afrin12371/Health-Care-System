package com.cg.hms.exception;

public class TestDoesNotExistException extends RuntimeException {

	public TestDoesNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
