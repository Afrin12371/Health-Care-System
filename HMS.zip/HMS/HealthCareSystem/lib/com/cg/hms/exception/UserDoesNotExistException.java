package com.cg.hms.exception;

public class UserDoesNotExistException extends RuntimeException {

	public UserDoesNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
