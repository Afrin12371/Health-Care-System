package com.cg.hms.exception;

public class UserNameAlreadyExist extends RuntimeException {

	public UserNameAlreadyExist(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
