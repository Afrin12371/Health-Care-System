package com.cg.hms.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.cg.hms.dto.CenterDetails;
import com.cg.hms.dto.TestDetails;
import com.cg.hms.entities.DiagnosticCenter;
import com.cg.hms.entities.Test;

@Component
public class DiagnosticUtil {

	public CenterDetails toDetails(DiagnosticCenter center) {
		Set<Test> test = center.getListOfTests();
		Set<TestDetails> details = new HashSet<>();
		for (Test test1 : test) {
			details.add(new TestDetails(test1));
			
		}
		return new CenterDetails(center.getCenterId(),center.getCenterName(),details);
	}

	public CenterDetails toDetails(DiagnosticCenter center, Test test) {
		Set<Test> tests = center.getListOfTests();
		Set<TestDetails> details = new HashSet<>();
		for (Test test1 : tests) {
			if(test1.getTestId() == test.getTestId())
			details.add(new TestDetails(test1));
			
		}
		return new CenterDetails(center.getCenterId(),center.getCenterName(),details);
	}

	public CenterDetails toDetails(DiagnosticCenter center, TestDetails tDetails) {
		Set<Test> tests = center.getListOfTests();
		Set<TestDetails> details = new HashSet<>();
		int n = tests.size();
		int n1 = 0;
		for (Test test1 : tests) {
			if(test1.getTestId() != tDetails.getTestId())
			n1++;
		}
		if(n==n1)
		details.add(new TestDetails(new Test(tDetails.getTestId(),tDetails.getTestName())));
		return new CenterDetails(center.getCenterId(),center.getCenterName(),details);
	}

	
	public Set<TestDetails> toDetails(Set<Test> listOfTests) {
		Set<TestDetails> details = new HashSet<TestDetails>();
		for( Test test: listOfTests) {
			details.add(new TestDetails(test));
		}
		return details;
	}

	public CenterDetails toDetails(DiagnosticCenter center, Set<TestDetails> tDetails) {
//		Set<TestDetails> details = new HashSet<TestDetails>();
//		for( TestDetails test: tDetails) {
//			details.add(new TestDetails(test));
//		}
		return new CenterDetails(center.getCenterId(),center.getCenterName(), tDetails);
	}

	public List<CenterDetails> toDisplayDetails(List<DiagnosticCenter> center, List<Test> test) {
		List<CenterDetails> detailsList = new ArrayList<CenterDetails>();
		
		
		for(int i =0; i<center.size();i++) {
			Set<TestDetails> tDetails = new HashSet<TestDetails>();
			for(int j =0 ;j<test.size();j++) {
				
				if(center.get(i).getCenterId()== test.get(j).getdCenter().getCenterId())
					tDetails.add(new TestDetails(
							test.get(j).getTestId(),test.get(j).getTestName()));
				
			}
			
			detailsList.add(new CenterDetails(center.get(i).getCenterId(),
					center.get(i).getCenterName(), tDetails));
		}
		return detailsList;
	}

	
}
